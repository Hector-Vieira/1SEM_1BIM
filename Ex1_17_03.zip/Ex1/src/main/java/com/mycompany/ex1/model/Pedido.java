/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ex1.model;
import java.util.ArrayList;
/**
 *
 * @author hector80605
 */
public class Pedido {
    ArrayList<String> itens = new ArrayList<String>();
    private Item item;
}
